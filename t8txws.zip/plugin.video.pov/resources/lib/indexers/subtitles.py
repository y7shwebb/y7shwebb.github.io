import json
import os
import requests
from datetime import timedelta
from caches.main_cache import MainCache
from modules.meta_lists import language_choices
from modules import kodi_utils
# from modules.kodi_utils import logger

ls, get_setting = kodi_utils.local_string, kodi_utils.get_setting
search_url = 'https://sub.wyzie.ru/search'
timeout = 5.05

def _get(url, params=None, stream=False, retry=False):
	response = requests.get(url, params=params, stream=stream, timeout=timeout)
	if retry and response.status_code in (403, 429):
		kodi_utils.notification(32740)
		kodi_utils.sleep(10000)
		return _get(url, params=params, stream=stream)
	return response

def subtitles_download(url):
	response = _get(url, stream=True, retry=True)
	return response if response.ok else response.reason

def subtitles_search(imdb_id, season=None, episode=None):
	cache_name = 'subtitles_wyzie_%s' % imdb_id
	params = {'id': imdb_id, 'format': 'srt'}
	if season:
		cache_name += '_%s_%s' % (season, episode)
		params.update({'season': season, 'episode': episode})
	maincache = MainCache()
	cache = maincache.get(cache_name)
	if cache: return cache
	response = _get(search_url, params=params, retry=True)
	if not response.ok: return []
	response = response.json()
	if response: maincache.set(cache_name, response, expiration=timedelta(hours=24))
	return response

class Subtitles(kodi_utils.xbmc_player):
	def __init__(self):
		kodi_utils.xbmc_player.__init__(self)
		self.auto_enable = get_setting('subtitles.auto_enable')
		self.subs_action = {'0': 'auto', '1': 'select', '2': 'off'}[get_setting('subtitles.subs_action', '2')]
		self.language1 = language_choices[get_setting('subtitles.language')]

	def _select_embedded_subtitle_once(self):
		def _is_brazil_text(text):
			return any(i in text for i in ('brazil', 'brasil', 'brazilian', 'pt-br', 'ptbr', 'pt_br'))
		def _is_portugal_text(text):
			return any(i in text for i in ('portugal', 'iberian', 'european', 'pt-pt', 'ptpt', 'pt_pt'))
		try:
			player_query = {"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}
			player_resp = json.loads(kodi_utils.execJSONRPC(json.dumps(player_query)))
			player_id = next((p.get('playerid') for p in player_resp.get('result', []) if p.get('type') == 'video'), None)
			if player_id is None: return False
			props_query = {
				"jsonrpc": "2.0",
				"method": "Player.GetProperties",
				"params": {"playerid": player_id, "properties": ["subtitles", "currentsubtitle", "subtitleenabled"]},
				"id": 1
			}
			props_resp = json.loads(kodi_utils.execJSONRPC(json.dumps(props_query)))
			props = props_resp.get('result', {})
			subtitles = props.get('subtitles') or []
			if not subtitles: return False
			search_lang = (kodi_utils.convert_language(self.language1, format='short') or '').lower()
			def _sub_text(sub):
				lang = (sub.get('language') or '')
				name = (sub.get('name') or '')
				return ('%s %s' % (lang, name)).lower()
			def _lang_matches(sub):
				lang = (sub.get('language') or '').lower()
				if lang:
					candidates = {search_lang, (self.language1 or '').lower()}
					if search_lang == 'pt' or (self.language1 or '') in ('por', 'pob'):
						candidates.update(('pt', 'por', 'pob', 'pt-br', 'pt_br', 'ptbr'))
					return lang in candidates
				return 'portuguese' in _sub_text(sub)
			if self.language1 in ('por', 'pob') or search_lang == 'pt':
				if self.language1 == 'por':
					idx = next((s.get('index') for s in subtitles if _lang_matches(s) and _is_portugal_text(_sub_text(s))), None)
					if idx is None:
						idx = next((s.get('index') for s in subtitles if _lang_matches(s) and not _is_brazil_text(_sub_text(s))), None)
				elif self.language1 == 'pob':
					idx = next((s.get('index') for s in subtitles if _lang_matches(s) and _is_brazil_text(_sub_text(s))), None)
				else:
					idx = next((s.get('index') for s in subtitles if _lang_matches(s)), None)
			else:
				idx = next((s.get('index') for s in subtitles if _lang_matches(s)), None)
			if idx is None: return False
			current = props.get('currentsubtitle')
			if isinstance(current, dict) and current.get('index') == idx: return True
			set_query = {"jsonrpc": "2.0", "method": "Player.SetSubtitle", "params": {"playerid": player_id, "subtitle": idx}, "id": 1}
			kodi_utils.execJSONRPC(json.dumps(set_query))
			return True
		except: return False

	def select_embedded_subtitle(self, retries=0, sleep_ms=0):
		retries = max(retries, 0)
		for attempt in range(retries + 1):
			if self._select_embedded_subtitle_once():
				if self.auto_enable == 'true': self.showSubtitles(True)
				return True
			if sleep_ms and attempt < retries: kodi_utils.sleep(sleep_ms)
		return False

	def run(self, query, imdb_id, season, episode, poster):
		def _video_file_subs():
			if self.select_embedded_subtitle():
				kodi_utils.notification(32852, icon=poster)
				return True
			try: available_sub_language = self.getSubtitles()
			except: available_sub_language = ''
			if not available_sub_language == self.language1: return False
			if self.auto_enable == 'true': self.showSubtitles(True)
			kodi_utils.notification(32852, icon=poster)
			return True
		def _downloaded_subs():
			files = kodi_utils.list_dirs(subtitle_path)[1]
			final_match = next((i for i in files if i == search_filename), None)
			if not final_match: return False
			subtitle = '%s%s' % (subtitle_path, final_match)
			kodi_utils.notification(32792, icon=poster)
			return subtitle
		def _searched_subs():
			search_language = kodi_utils.convert_language(self.language1, format='short')
			result = subtitles_search(imdb_id, season, episode)
			if not result: return kodi_utils.notification(32793, icon=poster)
			def _is_brazil(item):
				display = (item.get('display') or '').lower()
				flag = (item.get('flagUrl') or '').lower()
				text = '%s %s' % (display, flag)
				return any(i in text for i in ('brazil', 'brasil', 'brazilian', 'pt-br', 'ptbr', 'pt_br'))
			def _is_portugal(item):
				display = (item.get('display') or '').lower()
				flag = (item.get('flagUrl') or '').lower()
				text = '%s %s' % (display, flag)
				return any(i in text for i in ('portugal', 'iberian', 'european', 'pt-pt', 'ptpt', 'pt_pt'))
			def _lang_matches(item):
				lang = (item.get('language') or '').lower()
				if not lang: return False
				search_lang = (search_language or '').lower()
				candidates = {search_lang, (self.language1 or '').lower()}
				if search_lang == 'pt' or (self.language1 or '') in ('por', 'pob'):
					candidates.update(('pt', 'por', 'pob', 'pt-br', 'pt_br', 'ptbr'))
				return lang in candidates
			result.sort(key=lambda k: k['display'], reverse=False)
			result.sort(key=_lang_matches, reverse=True)
			def _auto_choice_index():
				if search_language == 'pt' or (self.language1 or '') in ('por', 'pob'):
					if self.language1 == 'por':
						idx = next((i for i, _ in enumerate(result) if _lang_matches(_) and _is_portugal(_)), -1)
						if idx >= 0: return idx
						idx = next((i for i, _ in enumerate(result) if _lang_matches(_) and not _is_brazil(_)), -1)
						if idx >= 0: return idx
					elif self.language1 == 'pob':
						idx = next((i for i, _ in enumerate(result) if _lang_matches(_) and _is_brazil(_)), -1)
						if idx >= 0: return idx
				return next((i for i, _ in enumerate(result) if _lang_matches(_)), -1)
			if self.subs_action == 'select' and len(result) > 1:
				try: video_path = self.getPlayingFile()
				except: video_path = ''
				if '|' in video_path: video_path = video_path.split('|')[0]
				video_path = os.path.basename(video_path)
				heading = '%s - %s' % (ls(32246).upper(), video_path)
				def _builder():
					for i in result:
						listitem = kodi_utils.make_listitem()
						listitem.setLabel('%s%s' % (i['display'].upper(), ' (SDH)' if i['isHearingImpaired'] else ''))
						listitem.setLabel2('%s[CR]%s' % (i['source'].upper(), i['media']))
						listitem.setArt({'icon': i['flagUrl'].replace('24.png', '64.png')})
						yield listitem
				self.pause()
				chosen_sub = kodi_utils.dialog.select(heading, list(_builder()), useDetails=True)
				self.pause()
			else: chosen_sub = _auto_choice_index()
			if chosen_sub < 0: return kodi_utils.notification(32736, icon=poster)
			chosen_sub = result[chosen_sub]
			try: lang = kodi_utils.convert_language(chosen_sub['language'])
			except: lang = chosen_sub['language']
			encoding = chosen_sub['encoding'].lower()
			final_filename = sub_filename + '_%s.%s' % (lang, chosen_sub['format'])
			final_path = '%s%s' % (subtitle_path, final_filename)
			response = subtitles_download(chosen_sub['url'])
			if isinstance(response, str): return kodi_utils.notification('Subtitles Error: %s' % response)
			try:
				if not 'utf-8' in encoding:
					import codecs
					content = codecs.decode(response.content, encoding=encoding)
				else: content = response.text
			except: content = response.content
			with kodi_utils.open_file(final_path, 'w') as file: file.write(content)
			kodi_utils.sleep(1000)
			return final_path
		if not self.subs_action in ('auto', 'select'): return
		kodi_utils.sleep(2500)
		subtitle_path = 'special://temp/'
		sub_filename = 'POVSubs_%s_%s_%s' % (imdb_id, season, episode) if season else 'POVSubs_%s' % imdb_id
		search_filename = sub_filename + '_%s.srt' % self.language1
		subtitle = _video_file_subs()
		if subtitle: return
		subtitle = _downloaded_subs()
		if subtitle: return self.setSubtitles(subtitle)
		subtitle = _searched_subs()
		if subtitle: return self.setSubtitles(subtitle)

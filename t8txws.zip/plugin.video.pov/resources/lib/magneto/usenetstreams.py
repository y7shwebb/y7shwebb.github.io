# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

import re
from json import loads as jsloads
from urllib.parse import urlparse

from fenom import client
from fenom import source_utils
from fenom.control import setting as getSetting


class source:
	timeout = 7
	priority = 1
	pack_capable = False # packs parsed in sources function
	hasMovies = True
	hasEpisodes = True
	def _quality_token_from_meta(self, meta):
		value = (meta.get('resolution') or meta.get('quality') or '').strip()
		if not value: return None
		tokens = re.sub(r'[^a-z0-9]+', ' ', value.lower()).split()
		if not tokens: return None
		if any('2160' in t for t in tokens) or '4k' in tokens or 'uhd' in tokens:
			return '2160p'
		if any('1080' in t for t in tokens) or 'fhd' in tokens:
			return '1080p'
		if any('720' in t for t in tokens) or 'hd' in tokens:
			return '720p'
		return None
	def _has_resolution_token(self, name_info):
		if not name_info: return False
		name_info = name_info.lower()
		return any(token in name_info for token in ('2160', '4k', 'uhd', '1080', '720'))
	def _base_from_manifest(self, manifest_url):
		if not manifest_url: return None
		try:
			if '://' not in manifest_url:
				manifest_url = 'https://%s' % manifest_url
			parsed = urlparse(manifest_url)
			if not parsed.scheme or not parsed.netloc: return None
			path = parsed.path or ''
			for suffix in ('/manifest.json', '/manifest'):
				if path.endswith(suffix):
					path = path[:-len(suffix)]
					break
			base_url = '%s://%s%s' % (parsed.scheme, parsed.netloc, path)
			return base_url.rstrip('/')
		except:
			return None
	def __init__(self):
		self.language = ['en']
		manifest_url = getSetting('usenetstreams.manifest_url', '').strip()
		self.base_link = self._base_from_manifest(manifest_url) if manifest_url else None
		self.movieSearch_link = '/stream/movie/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		self.min_seeders = 0

	def sources(self, data, hostDict):
		sources = []
		if not data or not self.base_link: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			total_seasons = data['total_seasons'] if 'tvshowtitle' in data else None
			year = data['year']
			imdb = data['imdb']
			if 'tvshowtitle' in data:
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, episode))
			else:
				hdlr = year
				url = '%s%s' % (self.base_link, self.movieSearch_link % imdb)
			if 'timeout' in data: self.timeout = int(data['timeout'])
			results = client.request(url, timeout=self.timeout)
			files = jsloads(results).get('streams') or []
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('USENETSTREAMS')
			return sources

		for file in files:
			try:
				package, episode_start = None, 0
				meta = file.get('meta') or {}
				direct_url = file.get('url')
				if not direct_url: continue

				release_title = meta.get('originalTitle') or ''
				if not release_title:
					title_line = file.get('title') or file.get('description') or ''
					release_title = title_line.split('\n')[0].strip() if title_line else ''
				if not release_title:
					release_title = file.get('name') or ''
				name = source_utils.clean_name(release_title)
				if not name: continue

				if not source_utils.check_title(title, aliases, name, hdlr, year):
					if total_seasons is None: continue
					valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name, total_seasons)
					if not valid:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name)
						if not valid: continue
						else: package = 'season'
					else: package = 'show'
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if not self._has_resolution_token(name_info):
					quality_token = self._quality_token_from_meta(meta)
					if quality_token:
						name_info = (name_info or '').rstrip('.')
						if name_info: name_info = '%s.%s.' % (name_info, quality_token)
						else: name_info = '.%s.' % quality_token
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				try:
					size_bytes = float(meta.get('size', 0))
					dsize = round(size_bytes / 1073741824, 2) if size_bytes > 0 else 0
				except:
					dsize = 0

				item = {
					'source': 'usenet', 'language': 'en', 'direct': True, 'debridonly': False,
					'provider': 'usenetstreams', 'url': direct_url, 'name': name, 'name_info': name_info,
					'size': dsize, 'seeders': 0, 'usenetstreams_direct': True, 'debrid': 'usenetstreams',
					'true_size': True
				}
				tracker = meta.get('indexer')
				if tracker: item['tracker'] = tracker
				if package: item['package'] = package
				if package == 'show': item.update({'last_season': last_season})
				if episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('USENETSTREAMS')
		return sources
